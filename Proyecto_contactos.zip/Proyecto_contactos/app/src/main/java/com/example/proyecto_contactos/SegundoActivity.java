package com.example.proyecto_contactos;

import android.os.Bundle;
import android.app.Activity;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SegundoActivity extends AppCompatActivity {
    private TextView textNombre, textTelefono, textEmail, textDesContacto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segundo);

        Bundle parametros = getIntent().getExtras();

        textNombre = (TextView) findViewById(R.id.textNombre);
        textTelefono = (TextView) findViewById(R.id.textTelefono);
        textEmail = (TextView) findViewById(R.id.textEmail);
        textDesContacto = (TextView) findViewById(R.id.textDesContacto);


        String Nombre = getIntent().getStringExtra("Nombre");
        String Telefono = getIntent().getStringExtra("Telefono");
        String Email = getIntent().getStringExtra("Email");
        String DesContacto = getIntent().getStringExtra("DesContacto");

        textNombre.setText(Nombre);
        textTelefono.setText(Telefono);
        textEmail.setText(Email);
        textDesContacto.setText(DesContacto);


    }


}
